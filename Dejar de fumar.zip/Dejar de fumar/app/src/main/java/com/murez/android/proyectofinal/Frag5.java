package com.murez.android.proyectofinal;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class Frag5 extends Fragment {


    private TabbedActivity activity;
    private ImageView unDia,tresDias,unaSemana,unMes,seisMeses,unAño;

    @SuppressLint("ResourceAsColor")


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag5_layout, container, false);

        Drawable Tick = getResources().getDrawable(R.drawable.tick);

        unDia = v.findViewById(R.id.unDia);
        tresDias = v.findViewById(R.id.tresDias);
        unaSemana = v.findViewById(R.id.unaSemana);
        unMes = v.findViewById(R.id.unMes);
        seisMeses = v.findViewById(R.id.seisMeses);
        unAño = v.findViewById(R.id.unAño);


        activity = (TabbedActivity) getActivity();
        String Dias = activity.datito;

        int auxdias = Integer.parseInt(Dias);

        if (auxdias >= 1)
        {
            unDia.setImageDrawable(Tick); //verde
        }

        if (auxdias >= 3)
        {
            tresDias.setImageDrawable(Tick); //verde
        }

        if (auxdias >= 7)
        {
            unaSemana.setImageDrawable(Tick); //verde
        }

        if (auxdias >= 31)
        {
            unMes.setImageDrawable(Tick); //verde
        }
        if (auxdias >= 182)
        {
            seisMeses.setImageDrawable(Tick); //verde
        }
        if (auxdias >= 365)
        {
            unAño.setImageDrawable(Tick); //verde
        }
        return v;

    }
}
